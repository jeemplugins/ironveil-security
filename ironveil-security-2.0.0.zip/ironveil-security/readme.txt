=== IronVeil Security ===
Contributors: ironveil
Tags: security, firewall, malware scanner, login security, server scan
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight security: firewall with threat feeds, brute-force protection, malware and server scanners, and an activity log.

== Description ==

Developed by **Jassim T Mohammad**.

IronVeil tries to stop attacks before WordPress spends CPU on them. The firewall checks each request with no extra database queries and no file reads. The scanner does its heavy work in short, time-limited background batches.

Everything below is included in this free plugin, with no time limit and no account required.

= Firewall (WAF) =
* Rule groups for SQL injection, XSS, path traversal/LFI, remote code and command execution (including remote file inclusion), PHP object injection, malicious uploads, vulnerability probes (.env, .git, backups, shells) and known attack tools. Each group is compiled into one regex, and input is normalised first (multi-pass URL decoding, HTML entities, \x/\u escapes, MySQL comment obfuscation).
* Server-side request forgery (SSRF): blocks cloud-metadata addresses (AWS, Google Cloud, Azure, Alibaba), gopher/dict/ldap smuggling and loopback URLs submitted by visitors.
* XML external entities (XXE) in form fields and in raw XML bodies such as XML-RPC.
* HTTP header (CRLF) injection and response splitting.
* HTTP protocol enforcement: unusual methods (TRACE, PROPFIND…), null bytes, oversized URLs, malformed Host headers and empty user agents on login and XML-RPC posts.
* Threat-intelligence IP feeds (opt-in): Spamhaus DROP / DROPv6 hijacked networks and Tor exit nodes, refreshed daily, still with zero database queries per request.
* Fails closed on regex engine errors caused by crafted input.
* Protect, monitor-only (learning) and off modes.
* IP/CIDR blocklist (IPv4 and IPv6). The firewall reads it from an autoloaded cache, so a lookup adds no query.
* Auto-blocks repeat attackers, 404 floods (vulnerability scanners) and brute-forcers. The optional global rate limit runs only when a persistent object cache is present, so it never writes to the database.
* Detects fake Googlebot/Bingbot with reverse and forward DNS checks, cached per IP.
* Resists IP spoofing: proxy headers are only trusted from configured proxies. Has built-in "cloudflare" and "private" presets.
* Logged-in editors and admins are recognised by a validated auth cookie, so their legitimate HTML is never blocked. A forged cookie gets no exemption.

= Login security =
* Per-IP brute-force lockouts that escalate to a 24-hour site-wide block. Locked-out requests skip password hashing entirely, which saves CPU.
* Protection against distributed attacks on one account: after many failures on a username, only IPs that previously logged in successfully as that user are accepted.
* Rejects breached passwords using the Have I Been Pwned k-anonymity check.
* Custom login URL that hides wp-login.php and /wp-admin.
* Blocks user enumeration (?author=, the REST users endpoint, the users sitemap, oEmbed) and uses generic login error messages.
* XML-RPC can be disabled or limited, and application passwords can be disabled. Idle sessions can be logged out, and you can end all sessions.

= Malware & vulnerability scanner =
* Incremental: files unchanged since a clean result are skipped without being read.
* Verifies WordPress core and wordpress.org plugins against official checksums, and trusts files that match.
* Checks IronVeil's own files against a shipped checksum manifest to detect tampering.
* Uses 30+ signatures and heuristics for web shells, backdoors, obfuscation, login backdoors, SEO spam, malicious .htaccess and JavaScript injections, plus PHP in uploads and PHP hidden in images.
* Scans posts and widgets for injected scripts.
* Flags outdated, closed and abandoned plugins and themes.
* Deep scan on demand: re-checks every file, including ones unchanged since the last clean result.
* Reversible quarantine, and one-click core file repair that is verified against the checksum before anything is written.
* **Bulk actions with checkboxes:** tick any number of findings (or use "Select: Critical / High+ / Medium+") and choose Clean, Quarantine or Ignore. "Clean" applies the safest fix for each finding: the official copy for WordPress core and wordpress.org plugin files, the quarantine for files that are malware as a whole, surgical removal of injected code (syntax-checked, re-scanned, backed up) for your own theme and plugin files, script removal for posts (a revision is kept) and updates for vulnerable plugins and themes. An optional checkbox quarantines files that cannot be cleaned safely. Quarantined files can be restored or deleted in bulk too.
* Reports new and changed code files between scans.

= Server security scanner =
* Audits what a file scan cannot see: end-of-life PHP and database versions, dangerous PHP settings (allow_url_include, display_errors, shell functions, open_basedir), unexpected auto_prepend_file, PHP running as root, database users with server-wide privileges or weak passwords.
* Files: wp-config.php and world-writable permissions, wp-config backups, .env files, database dumps, backup archives and logs in public folders, phpinfo/Adminer/installer leftovers, .git folders, PHP droppers in /tmp and /dev/shm, must-use plugins to review.
* HTTP checks against your own site: security headers, version disclosure, HTTP-to-HTTPS redirect, TLS certificate expiry, directory listing, downloadable debug.log/.git/.env and the TRACE method.
* Network: database, cache and legacy services (MySQL, PostgreSQL, Redis, Memcached, MongoDB, Elasticsearch, FTP, Telnet) listening on the server's public address.
* Results appear as findings with checkboxes. Clean fixes permissions, quarantines exposed files and writes protective .htaccess rules; everything else comes with the exact configuration fix. Runs weekly by default.

= Hardening & monitoring =
* Security headers (including a baseline Content-Security-Policy), optional HSTS, file editor lock, version hiding, a REST API restriction option, and PHP execution blocking in uploads.
* Comment spam honeypot with a signed time trap. Pingbacks can be disabled.
* Security score and checklist.
* Activity log covering logins, users, roles, plugins, themes, critical options, content, application passwords and firewall events. Each entry is HMAC-signed so edits and deletions can be detected.
* Email alert when a user receives the administrator role.
* **Report a bug:** IronVeil → Report a Bug emails your description, and optional redacted diagnostics you can read first, to ironveil.wpplug@gmail.com. Nothing is sent without your explicit consent. Internal errors are recorded so they can be included.
* WP-CLI commands: `wp ironveil status|scan|clean|server-scan|block|unblock|firewall|update-feeds|reset-login-url|license`.
* Available in English, French, Spanish, Arabic (right-to-left) and Turkish.

= IronVeil Pro =

IronVeil Pro is a separate, paid version sold at https://jeemplugins.com/ironveilsecurity. It adds:

* The ClamAV antivirus engine (every file type, including archives and binaries) when the server runs clamd.
* Scanning other folders on the server, scheduled deep scans, and CVE matching through WPScan.
* Automatic, signed signature updates and custom detection rules.
* Automatic quarantine of critical findings and automatic core-file repair.
* Country blocking, email alerts for scans, lockouts, logins and plugin changes, and extended protection (the firewall loads before every other plugin).

== Performance ==

* Firewall cost on a normal request: about 0.06 ms for all 12 rule groups and 0 extra database queries (measured on PHP 8.3). Threat feeds add a binary search over a compact 30 KB list (about 0.03 ms), never a query.

* Database writes only happen on security events such as attacks, failed logins and 404s from anonymous visitors. Normal page views never write.
* Scans run in steps of at most 8 seconds. A second scan of an unchanged site of about 1,150 code files re-reads only the files that changed.

== Frequently Asked Questions ==

= Does IronVeil slow my site down? =

Not noticeably: the firewall adds about 0.06 ms and no database queries to a normal request. Scans run in the background in short steps.

= I locked myself out. What now? =

See "Emergency access" below: one line in wp-config.php turns the firewall or the custom login URL off.

= Is IronVeil translated? =

Yes. IronVeil ships with French, Spanish, Arabic and Turkish translations. The admin screens switch to right-to-left automatically in Arabic.

== Emergency access ==

Add one of these to wp-config.php:

* `define( 'IRONVEIL_DISABLE_FIREWALL', true );` turns off the firewall (useful if you blocked yourself).
* `define( 'IRONVEIL_DISABLE_LOGIN_SLUG', true );` makes wp-login.php work again.

Or use WP-CLI: `wp ironveil unblock <ip>`, `wp ironveil reset-login-url`, `wp ironveil firewall monitor`.

== nginx ==

nginx ignores .htaccess files. Add this to your server block:

    location ~* /wp-content/uploads/.*\.(php[0-9]?|phtml|phar)$ { deny all; }
    location ~* /(\.(env|git|ht)|wp-config\.php|readme\.html|license\.txt) { deny all; }

== Privacy ==

The breach check sends only the first 5 characters of a SHA-1 hash to api.pwnedpasswords.com. Bug reports are only sent when you submit the form and tick the consent box. Freemius (see below) only receives data if you opt in. See "External services" for every connection IronVeil can make.

== External services ==

IronVeil connects to these services. Each one is used only for the purpose described.

* **WordPress.org** (api.wordpress.org, downloads.wordpress.org, core.svn.wordpress.org, plugins.svn.wordpress.org): official checksums of WordPress core and plugins, plugin status (closed/abandoned), and official copies of core and plugin files when you click Repair or Clean. Sent: WordPress version, locale, plugin slugs and versions, and the requested file path. Terms: https://wordpress.org/about/privacy/
* **Have I Been Pwned** (api.pwnedpasswords.com), when "Reject breached passwords" is on: the first 5 characters of the SHA-1 hash of a new password. Terms: https://haveibeenpwned.com/Privacy
* **Spamhaus** (www.spamhaus.org), only if you enable the Spamhaus DROP feed: a daily download of the public DROP list; your site address is sent in the User-Agent. Terms: https://www.spamhaus.org/organization/privacy/
* **Tor Project** (check.torproject.org), only if you enable the Tor feed: a daily download of the public exit-node list. Terms: https://www.torproject.org/about/privacy/
* **Freemius** (api.freemius.com, checkout.freemius.com): licensing and checkout for IronVeil Pro. After activation IronVeil asks whether you want to opt in; only if you agree are your name, email, site address, WordPress, PHP and plugin versions, and plugin activation events sent. You can skip the opt-in and IronVeil works the same. The checkout only loads when you choose to buy Pro. Terms: https://freemius.com/terms/ and privacy: https://freemius.com/privacy/
* **Email to ironveil.wpplug@gmail.com**, only when an administrator submits IronVeil → Report a Bug with the consent box ticked: the description you typed, your site address, the reply-to address you entered, and (if ticked) the redacted diagnostics shown on that page. Sent through your site's own mail setup.
* **Your own site** (loopback requests), during server scans: checks headers, exposed files and the TLS certificate. Nothing leaves your server.

== Changelog ==

= 2.0.0 =
* New: licensing, checkout and Pro updates through Freemius. Old IronVeil license keys (IVL1…) no longer apply; Pro customers activate their Freemius license from IronVeil → Account.
* New: the free plugin contains only free features. Pro features are a separate download, so nothing in the free plugin is locked.
* New: French, Spanish, Arabic and Turkish translations, and right-to-left admin screens.
* New: admin header and menu icon use the IronVeil brand mark; the Pro upsell is shown only on the dashboard.
* Changed: alert emails are translatable and link to the right admin screen on multisite.
* Changed: uninstall cleanup runs through Freemius ("after_uninstall"), or WordPress directly when Freemius is not configured; IRONVEIL_KEEP_DATA still keeps all data.
* Removed: the offline license-key system, its `wp ironveil license activate|deactivate` commands and license revocation through the signature feed.
* Upgrade: old license data is deleted automatically.

= 1.3.2 =
* New: Pro sites follow the official signed signature feed at jeemplugins.com by default. License revocations are always read from the official feed, even when a custom feed is configured.
* Plugin URI is now https://jeemplugins.com/ironveilsecurity; the "Buy Pro" link points there too.
* WordPress.org Plugin Check fixes: owner command-line tools and the installation guide are no longer shipped inside the plugin; all custom-table queries use prepared %i identifiers; every admin form handler verifies its security token explicitly; the "Tested up to" and short description were updated.
* The quarantine folder moved from wp-content to a randomly named folder inside uploads. Existing quarantined files are moved automatically.
* Requires WordPress 6.2 or newer (needed for %i placeholders).
* Removed: administrator identity verification (emailed codes for sensitive actions), its settings, its security-score item, its alert and the `unlock-verify` WP-CLI command.

= 1.3.1 =
* Removed: two-factor authentication (authenticator apps, recovery codes, "trust this device" and per-role enforcement), its WP-CLI command `reset-2fa`, the `IRONVEIL_DISABLE_2FA` constant and the 2FA item of the security score. Updating deletes the stored 2FA secrets and recovery codes.
* Changed: administrator identity verification now uses emailed codes only, so the "Allow emailed verification codes" setting was removed.
* Changed: the Login Security page lists privileged users with their breached-password status.

= 1.3.0 =
* New: administrator identity verification ("sudo mode"). One verification, by authenticator, recovery or emailed code, protects every sensitive action on an administrator account for a configurable window. A two-factor login counts as verified. Failed codes are rate limited, logged and alerted.
* New: checkboxes and bulk actions for scan findings (Clean, Quarantine, Ignore, Stop ignoring) and for the quarantine (Restore, Delete). Includes quick selection by severity and a per-row Clean button that shows what it will do.
* New: Clean restores official wordpress.org plugin files, surgically removes injected code from theme and custom-plugin files (syntax-checked, re-scanned, backed up), removes injected scripts from posts and widgets (revision kept) and updates vulnerable plugins and themes. Optionally it quarantines files that cannot be cleaned safely.
* New: server security scanner (PHP, database, permissions, exposed files, temp-folder droppers, HTTP headers, TLS expiry, exposed service ports) with fixable findings, a report page, weekly schedule and email alerts.
* New: firewall rule groups for SSRF, XXE (including raw XML bodies), CRLF/header injection and HTTP protocol enforcement, plus a remote-file-inclusion rule.
* New: Spamhaus DROP and Tor exit-node threat-intelligence feeds.
* New: baseline Content-Security-Policy (frame-ancestors, base-uri) and X-Permitted-Cross-Domain-Policies headers. WordPress post embeds stay frameable.
* New: Report a Bug page that emails ironveil.wpplug@gmail.com with consent and a redacted diagnostics preview. Internal errors are captured for reports.
* New WP-CLI commands: `server-scan`, `clean`, `unlock-verify`, `update-feeds`.
* Security: two-factor codes are rate limited per account, across login attempts and on the profile screen. 2FA cannot be re-enrolled over an existing secret. 2FA changes require a verified session.
* Security: quarantine and tools folders use deny rules that work on Apache 2.2 and 2.4 (the old rule could cause a 500 error on Apache 2.4). Files over 50 MB are no longer read into memory for quarantine. Plugin folders now have index.php guards.
* Fix: the classic `' OR '1'='1' --` SQL injection with a closing quote is now blocked.
* Fix: the login honeypot field is no longer autofilled by password managers, which could block real users.
* Fix: a 2FA lockout now says so instead of "session expired".
* Fix: security headers no longer stop WordPress post embeds from being framed by other sites.
* Upgrade: existing sites get the new firewall groups and alert types turned on automatically.


= 1.2.1 =
* Fix: "Repair" no longer fails with "File is not writable" on common hosting setups. It now tries, in order: a safe atomic replace, an in-place overwrite (when the folder is read-only), temporarily unlocking read-only (0444) files the site owns, and FTP/SSH credentials from wp-config.php. When none of these is allowed, the message explains exactly why and what to do.
* New: "View changes" shows a side-by-side comparison of a modified core file with the official WordPress copy.
* New: "Download original" gives you the verified official file to upload yourself.
* Fix: WordPress's own oEmbed cache and embed iframes are no longer reported as suspicious scripts, and the hidden-iframe rule no longer matches marginwidth/marginheight.
* New: PHP files in the WordPress root that are not part of WordPress are reported. Added known backdoor filenames (accesson.php and others).
* Repairing or quarantining a file now closes all findings for that file, and a failed repair no longer leaves a stray backup.

= 1.2.0 =
* New: Free and Pro editions with offline, domain-bound Ed25519 license keys (paid, complimentary and owner types), expiry, and revocation through the signed feed.
* New: License / Upgrade page, PRO badges and locked settings in the Free edition. Stored Pro settings are kept and return when a key is added.
* New: license generator tool (ironveil-license.php in the owner tools) and `wp ironveil license status|activate|deactivate`.
* Author: Jassim T Mohammad.

= 1.1.0 =
* New: ClamAV integration through the clamd socket (INSTREAM), with every file type scanned, auto-detection, EICAR self-test and outage handling.
* New: scan additional server folders outside WordPress.
* New: deep scans, automatic (weekly by default) or on demand.
* New: Ed25519-signed signature update feed with rollback and expiry protection, a signing tool, and custom admin-defined rules.
* New WP-CLI commands: `scan --deep`, `clamav-test` and `update-signatures`.

= 1.0.0 =
* First release.

== Upgrade Notice ==

= 2.0.0 =
Licensing moves to Freemius: old IronVeil license keys no longer apply. Adds French, Spanish, Arabic and Turkish translations.
