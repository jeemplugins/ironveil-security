<?php
/**
 * Email alerts with per-type throttling (no inbox floods during attacks).
 *
 * The Free edition alerts when a user receives the administrator role. The
 * Pro module registers the other alert types through register().
 *
 * @package IronVeil
 */

namespace IronVeil;

defined( 'ABSPATH' ) || exit;

final class Notifier {

	/**
	 * Hooks.
	 */
	public static function init() {
		self::register( 'new_admin', 'ironveil_new_admin', array( __CLASS__, 'new_admin' ) );
	}

	/**
	 * Hook an alert handler if the admin enabled that alert type.
	 *
	 * @param string   $event    Setting value in notify_events.
	 * @param string   $hook     Action to listen to.
	 * @param callable $callback Handler.
	 * @param int      $args     Accepted arguments.
	 */
	public static function register( $event, $hook, $callback, $args = 1 ) {
		if ( in_array( $event, (array) Settings::get( 'notify_events' ), true ) ) {
			add_action( $hook, $callback, 10, $args );
		}
	}

	/**
	 * @return string
	 */
	private static function to() {
		$e = (string) Settings::get( 'notify_email' );
		return $e ? $e : (string) get_option( 'admin_email' );
	}

	/**
	 * Send an alert.
	 *
	 * @param string $type     Throttle bucket.
	 * @param string $subject  Subject.
	 * @param string $body     Body.
	 * @param int    $throttle Seconds (0 = none).
	 * @return bool
	 */
	public static function send( $type, $subject, $body, $throttle = 900 ) {
		if ( $throttle ) {
			$key = 'ironveil_mail_' . sanitize_key( $type );
			if ( get_transient( $key ) ) {
				return false;
			}
			set_transient( $key, 1, $throttle );
		}
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		/* translators: %s: site address */
		$body = $body . "\n\n—\n" . sprintf( __( 'IronVeil Security on %s', 'ironveil-security' ), home_url() ) . "\n" . Admin::url();
		return wp_mail( self::to(), sprintf( '[%1$s] IronVeil: %2$s', $site, $subject ), $body );
	}

	/**
	 * @param int $user_id User who became an administrator.
	 */
	public static function new_admin( $user_id ) {
		$u = get_userdata( $user_id );
		self::send(
			'new_admin_' . $user_id,
			__( 'New administrator', 'ironveil-security' ),
			/* translators: %s: user name */
			sprintf( __( "User \"%s\" now has the administrator role.\nIf you did not do this, your site may be compromised.", 'ironveil-security' ), $u ? $u->user_login : '#' . $user_id ),
			0
		);
	}
}
