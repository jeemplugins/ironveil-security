<?php
/**
 * Stand-in for the Freemius SDK object while the SDK is not configured
 * (no product ID / public key yet, or the freemius/ folder is missing).
 *
 * It implements only the methods IronVeil calls and always reports the Free
 * edition, so the plugin keeps working safely: nothing is unlocked and no
 * remote service is contacted.
 *
 * @package IronVeil
 */

namespace IronVeil;

defined( 'ABSPATH' ) || exit;

final class Freemius_Fallback {

	/** Where Pro can be bought while Freemius checkout is not available. */
	const PURCHASE_URL = 'https://jeemplugins.com/ironveilsecurity';

	/**
	 * Premium code is never active without Freemius.
	 *
	 * @return bool
	 */
	public function is__premium_only() {
		return false;
	}

	/** @return bool */
	public function is_premium() {
		return false;
	}

	/** @return bool */
	public function can_use_premium_code() {
		return false;
	}

	/** @return bool */
	public function is_paying() {
		return false;
	}

	/** @return bool */
	public function is_trial() {
		return false;
	}

	/** @return bool */
	public function is_not_paying() {
		return true;
	}

	/** @return bool */
	public function is_registered() {
		return false;
	}

	/** @return string */
	public function get_plan_title() {
		return '';
	}

	/** @return string */
	public function get_upgrade_url() {
		return self::PURCHASE_URL;
	}

	/** @return string */
	public function get_account_url() {
		return '';
	}

	/**
	 * Freemius-style hooks. "after_uninstall" is wired to WordPress directly
	 * (see Uninstaller::register_fallback_hook()); everything else is ignored.
	 *
	 * @return bool
	 */
	public function add_action() {
		return true;
	}

	/** @return bool */
	public function add_filter() {
		return true;
	}

	/**
	 * Freemius uses this to switch between the Free and Pro builds.
	 */
	public function set_basename() {
	}
}
