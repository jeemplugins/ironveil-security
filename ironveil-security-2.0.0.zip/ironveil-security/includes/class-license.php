<?php
/**
 * Edition and licensing (Free / Pro), backed by Freemius.
 *
 * Freemius handles checkout, subscriptions, license activation and Pro
 * updates. The Pro modules live in includes/pro/ and are only present in
 * the premium build (Freemius strips them from the free version), so the
 * free plugin contains no locked code.
 *
 * @package IronVeil
 */

namespace IronVeil;

defined( 'ABSPATH' ) || exit;

final class License {

	/** @var bool|null Per-request result. */
	private static $pro = null;

	/**
	 * Pro-only settings => the value they take while Pro is not active.
	 * Registered by the Pro module (premium build only).
	 *
	 * @var array
	 */
	private static $locks = array();

	/**
	 * Is Pro active on this site (premium build + valid license or trial)?
	 *
	 * @return bool
	 */
	public static function is_pro() {
		if ( null === self::$pro ) {
			// The Pro module is loaded by the main plugin file (premium build only) or
			// by the early firewall loader; the free build has no Pro class at all.
			self::$pro = class_exists( __NAMESPACE__ . '\Pro', false ) && Pro::entitled();
		}
		return self::$pro;
	}

	/**
	 * Register Pro-only settings and the value each takes while Pro is inactive.
	 *
	 * @param array $locks key => free value.
	 */
	public static function register_locks( array $locks ) {
		self::$locks = array_merge( self::$locks, $locks );
	}

	/**
	 * Is a setting Pro-only?
	 *
	 * @param string $key Setting.
	 * @return bool
	 */
	public static function is_pro_setting( $key ) {
		return array_key_exists( $key, self::$locks );
	}

	/**
	 * Value a Pro-only setting takes while Pro is inactive.
	 *
	 * @param string $key Setting.
	 * @return mixed
	 */
	public static function free_value( $key ) {
		return self::$locks[ $key ] ?? null;
	}

	/**
	 * Is the Freemius SDK configured (product ID and key set)?
	 *
	 * @return bool
	 */
	public static function freemius_ready() {
		return function_exists( 'ironveil_fs' ) && ! ( ironveil_fs() instanceof Freemius_Fallback );
	}

	/**
	 * Where to buy or upgrade.
	 *
	 * @return string
	 */
	public static function upgrade_url() {
		return function_exists( 'ironveil_fs' ) ? (string) ironveil_fs()->get_upgrade_url() : Freemius_Fallback::PURCHASE_URL;
	}

	/**
	 * Freemius account page (license, billing, downloads), or '' when unavailable.
	 *
	 * @return string
	 */
	public static function account_url() {
		return self::freemius_ready() && ironveil_fs()->is_registered() ? (string) ironveil_fs()->get_account_url() : '';
	}

	/**
	 * Summary for the admin screens, WP-CLI and bug reports.
	 *
	 * @return array { pro: bool, plan: string, trial: bool, freemius: bool }
	 */
	public static function status() {
		$fs = function_exists( 'ironveil_fs' ) ? ironveil_fs() : null;
		return array(
			'pro'      => self::is_pro(),
			'plan'     => $fs && self::is_pro() ? (string) $fs->get_plan_title() : '',
			'trial'    => $fs && self::is_pro() && $fs->is_trial(),
			'freemius' => self::freemius_ready(),
		);
	}

	/** Reset the per-request cache (after a license change). */
	public static function flush() {
		self::$pro = null;
	}
}
