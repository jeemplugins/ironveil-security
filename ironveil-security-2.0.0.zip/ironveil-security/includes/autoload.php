<?php
/**
 * PSR-4-ish autoloader: IronVeil\Foo_Bar => includes/class-foo-bar.php
 * (or includes/pro/class-foo-bar__premium_only.php in the premium build).
 *
 * @package IronVeil
 */

defined( 'ABSPATH' ) || exit;

spl_autoload_register(
	static function ( $class ) {
		if ( 0 !== strpos( $class, 'IronVeil\\' ) ) {
			return;
		}
		$name = substr( $class, 9 );
		if ( ! preg_match( '/^[A-Za-z0-9_]+$/', $name ) ) {
			return;
		}
		$base = 'class-' . strtolower( str_replace( '_', '-', $name ) );
		$file = __DIR__ . '/' . $base . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
			return;
		}
		// Pro modules. This folder only exists in the premium build: Freemius removes
		// every *__premium_only file from the free version.
		$file = __DIR__ . '/pro/' . $base . '__premium_only.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);
