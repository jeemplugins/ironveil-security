<?php
/**
 * IronVeil Pro: admin screens, handlers, WP-CLI commands and the early
 * firewall loader ("extended protection"). Premium build only.
 *
 * @package IronVeil
 */

namespace IronVeil;

defined( 'ABSPATH' ) || exit;

final class Pro_Admin {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'ironveil_admin_engine_rows', array( __CLASS__, 'engine_rows' ) );
		add_action( 'ironveil_admin_tools_cards', array( __CLASS__, 'tools_cards' ) );
		foreach ( array( 'mu', 'clamav_test', 'feed_update' ) as $a ) {
			add_action( 'admin_post_ironveil_' . $a, array( __CLASS__, 'post_' . $a ) );
		}
	}

	/**
	 * WP-CLI: Pro commands.
	 */
	public static function register_cli() {
		\WP_CLI::add_command( 'ironveil clamav-test', array( __CLASS__, 'cli_clamav_test' ), array( 'shortdesc' => 'Check that ClamAV works (EICAR self-test).' ) );
		\WP_CLI::add_command( 'ironveil update-signatures', array( __CLASS__, 'cli_update_signatures' ), array( 'shortdesc' => 'Download and verify the signed signature feed now.' ) );
	}

	/**
	 * Pro rows of the "Detection engines" table.
	 */
	public static function engine_rows() {
		$pro  = License::is_pro();
		$feed = Signature_Feed::state();

		echo '<tr><th scope="row">' . esc_html__( 'Signature updates', 'ironveil-security' ) . '</th><td>';
		if ( ! $pro ) {
			self::renew_link( __( 'Automatic signature updates need an active IronVeil Pro license.', 'ironveil-security' ) );
		} else {
			echo esc_html(
				(int) $feed['version']
					/* translators: 1: version 2: time */
					? sprintf( __( 'Version %1$d, updated %2$s ago.', 'ironveil-security' ), $feed['version'], human_time_diff( (int) ( $feed['updated'] ?? time() ) ) )
					: __( 'No feed installed yet.', 'ironveil-security' )
			);
			if ( ! empty( $feed['error'] ) ) {
				echo '<br><span class="iv-pill iv-bad">' . esc_html( $feed['error'] ) . '</span>';
			}
			if ( ! empty( $feed['rejected'] ) ) {
				/* translators: %d: count */
				echo '<br><small>' . esc_html( sprintf( _n( '%d rule in the feed was rejected as unsafe.', '%d rules in the feed were rejected as unsafe.', (int) $feed['rejected'], 'ironveil-security' ), (int) $feed['rejected'] ) ) . '</small>';
			}
		}
		echo '</td><td>';
		if ( $pro && '' !== Signature_Feed::url() ) {
			Admin::button_form( 'ironveil_feed_update', __( 'Update now', 'ironveil-security' ) );
		}
		echo '</td></tr>';

		$mode = Settings::get( 'clamav_mode' );
		echo '<tr><th scope="row">ClamAV</th><td>';
		if ( ! $pro ) {
			self::renew_link( __( 'The ClamAV engine needs an active IronVeil Pro license.', 'ironveil-security' ) );
		} elseif ( 'off' === $mode ) {
			echo '<span class="iv-pill">' . esc_html__( 'Off', 'ironveil-security' ) . '</span>';
		} else {
			$ep  = ClamAV::endpoint();
			$ver = $ep ? ClamAV::version() : false;
			if ( $ep ) {
				echo '<span class="iv-pill iv-good">' . esc_html__( 'Connected', 'ironveil-security' ) . '</span> <code>' . esc_html( $ep ) . '</code> ' . esc_html( (string) $ver );
				if ( $ver && preg_match( '~/(\d+)/(.+)$~', (string) $ver, $m ) && strtotime( $m[2] ) && strtotime( $m[2] ) < time() - 3 * DAY_IN_SECONDS ) {
					echo '<br><span class="iv-pill iv-warn">' . esc_html__( 'Virus database is more than 3 days old — check that freshclam is running.', 'ironveil-security' ) . '</span>';
				}
			} else {
				echo '<span class="iv-pill iv-warn">' . esc_html__( 'Not found', 'ironveil-security' ) . '</span> ' . esc_html__( 'Ask your host to install clamav-daemon (clamd) and freshclam, or enter its socket below. IronVeil\'s own engine keeps working without it.', 'ironveil-security' );
			}
		}
		echo '</td><td>';
		if ( $pro && 'off' !== $mode ) {
			Admin::button_form( 'ironveil_clamav_test', __( 'Test with EICAR', 'ironveil-security' ) );
		}
		echo '</td></tr>';
	}

	/**
	 * Extended protection card (Alerts & Tools).
	 */
	public static function tools_cards() {
		$mu = Installer::mu_loader_active();
		echo '<div class="iv-card"><h2>' . esc_html__( 'Extended protection', 'ironveil-security' ) . ' ' . ( $mu ? '<span class="iv-pill iv-good">' . esc_html__( 'Active', 'ironveil-security' ) . '</span>' : '<span class="iv-pill iv-warn">' . esc_html__( 'Off', 'ironveil-security' ) . '</span>' ) . '</h2>';
		echo '<p>' . esc_html__( 'Installs a tiny must-use loader so the firewall inspects requests before any other plugin runs. This protects against vulnerabilities in other plugins that trigger as soon as they load.', 'ironveil-security' ) . '</p>';
		if ( $mu || License::is_pro() ) {
			Admin::button_form( 'ironveil_mu', $mu ? __( 'Disable extended protection', 'ironveil-security' ) : __( 'Enable extended protection', 'ironveil-security' ), array( 'do' => $mu ? 'remove' : 'install' ) );
		} else {
			self::renew_link( __( 'Extended protection needs an active IronVeil Pro license.', 'ironveil-security' ) );
		}
		echo '</div>';
	}

	/**
	 * @param string $text Explanation.
	 */
	private static function renew_link( $text ) {
		echo '<span class="iv-pill iv-pro">PRO</span> ' . esc_html( $text ) . ' <a href="' . esc_url( Admin::pro_url() ) . '">' . esc_html__( 'Activate or renew', 'ironveil-security' ) . '</a>';
	}

	// ------------------------------------------------------------------ Handlers.

	public static function post_mu() {
		check_admin_referer( 'ironveil_mu' );
		Admin::guard( 'ironveil_mu' );
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		if ( 'install' === $do ) {
			$r = self::install_mu_loader();
			if ( is_wp_error( $r ) ) {
				Admin::back( Admin::SLUG . '-tools', $r->get_error_message(), 'error' );
			}
			Admin::back( Admin::SLUG . '-tools', __( 'Extended protection enabled.', 'ironveil-security' ) );
		}
		Installer::remove_mu_loader();
		Log::add( 'extended_protection', 'Extended protection disabled', Log::WARNING );
		Admin::back( Admin::SLUG . '-tools', __( 'Extended protection disabled.', 'ironveil-security' ) );
	}

	public static function post_clamav_test() {
		check_admin_referer( 'ironveil_clamav_test' );
		Admin::guard( 'ironveil_clamav_test' );
		delete_transient( 'ironveil_clamd_ep' );
		$r = ClamAV::self_test();
		Admin::back( Admin::SLUG . '-scanner', $r['message'], $r['ok'] ? 'success' : 'error' );
	}

	public static function post_feed_update() {
		check_admin_referer( 'ironveil_feed_update' );
		Admin::guard( 'ironveil_feed_update' );
		$r = Signature_Feed::update( true );
		if ( is_wp_error( $r ) ) {
			Admin::back( Admin::SLUG . '-scanner', $r->get_error_message(), 'error' );
		}
		/* translators: %d: version */
		Admin::back( Admin::SLUG . '-scanner', sprintf( __( 'Signatures updated to version %d.', 'ironveil-security' ), Signature_Feed::state()['version'] ) );
	}

	// ------------------------------------------------------------------ Early loader.

	/**
	 * Install the MU loader so the firewall (and Pro's network checks) run
	 * before every other plugin.
	 *
	 * @return true|\WP_Error
	 */
	public static function install_mu_loader() {
		if ( ! License::is_pro() ) {
			return new \WP_Error( 'ironveil_pro', __( 'Extended protection needs an active IronVeil Pro license.', 'ironveil-security' ) );
		}
		$dir = WPMU_PLUGIN_DIR;
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return new \WP_Error( 'ironveil_mu', __( 'Could not create the mu-plugins directory.', 'ironveil-security' ) );
		}
		$autoload = wp_normalize_path( IRONVEIL_DIR . 'includes/autoload.php' );
		$code     = "<?php\n"
			. "/**\n * Plugin Name: IronVeil Security – early firewall loader\n * Description: Runs the IronVeil firewall before other plugins. Managed by IronVeil Security; delete this file to disable.\n */\n"
			. "defined( 'ABSPATH' ) || exit;\n"
			. "if ( defined( 'IRONVEIL_DISABLE_FIREWALL' ) && IRONVEIL_DISABLE_FIREWALL ) { return; }\n"
			. '$ironveil_active = (array) get_option( \'active_plugins\', array() );' . "\n"
			. 'if ( is_multisite() ) { $ironveil_active = array_merge( $ironveil_active, array_keys( (array) get_site_option( \'active_sitewide_plugins\', array() ) ) ); }' . "\n"
			. 'if ( in_array( ' . var_export( IRONVEIL_BASENAME, true ) . ', $ironveil_active, true ) && is_readable( ' . var_export( $autoload, true ) . " ) ) {\n" // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_var_export
			. '	require_once ' . var_export( $autoload, true ) . ";\n" // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_var_export
			. "	if ( class_exists( '\\\\IronVeil\\\\Pro' ) ) { \\IronVeil\\Pro::boot(); }\n"
			. "	\\IronVeil\\Firewall::boot();\n"
			. "}\n"
			. "unset( \$ironveil_active );\n";
		$ok       = false !== file_put_contents( Installer::mu_path(), $code, LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( ! $ok ) {
			return new \WP_Error( 'ironveil_mu', __( 'Could not write the MU loader (check permissions).', 'ironveil-security' ) );
		}
		Log::add( 'extended_protection', 'Extended protection (early loader) enabled', Log::NOTICE );
		return true;
	}

	// ------------------------------------------------------------------ WP-CLI.

	/**
	 * wp ironveil clamav-test
	 */
	public static function cli_clamav_test() {
		$r = ClamAV::self_test();
		$r['ok'] ? \WP_CLI::success( $r['message'] ) : \WP_CLI::error( $r['message'] );
	}

	/**
	 * wp ironveil update-signatures
	 */
	public static function cli_update_signatures() {
		if ( ! License::is_pro() ) {
			\WP_CLI::error( 'Signature updates need an active IronVeil Pro license.' );
		}
		$r = Signature_Feed::update( true );
		if ( is_wp_error( $r ) ) {
			\WP_CLI::error( $r->get_error_message() );
		}
		$st = Signature_Feed::state();
		$c  = Signatures::counts();
		\WP_CLI::success( sprintf( 'Feed version %d installed. Rules: %d built-in, %d feed, %d custom.', $st['version'], $c['builtin'], $c['feed'], $c['custom'] ) );
	}
}
