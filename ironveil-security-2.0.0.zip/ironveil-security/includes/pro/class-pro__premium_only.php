<?php
/**
 * IronVeil Pro: bootstraps every premium feature.
 *
 * This file (and the whole includes/pro/ folder) only exists in the premium
 * build. Freemius removes it from the free version, which therefore contains
 * no locked code. The free plugin exposes hooks; this module plugs into them.
 *
 * @package IronVeil
 */

namespace IronVeil;

defined( 'ABSPATH' ) || exit;

final class Pro {

	/** Autoloaded HMAC of the last known license state (used by the early loader). */
	const STATE_OPTION = 'ironveil_pro_state';

	/** @var bool */
	private static $booted = false;

	/**
	 * Register settings and the network-level firewall check. Called from the
	 * main plugin file and from the early (mu-plugins) loader; idempotent.
	 */
	public static function boot() {
		if ( self::$booted ) {
			License::flush(); // Freemius may have loaded since the early loader ran.
			return;
		}
		self::$booted = true;
		License::flush();
		self::register_settings();
		Firewall::add_check( array( __CLASS__, 'country_check' ) );
		add_action( 'plugins_loaded', array( __CLASS__, 'init' ), 2 );
	}

	/**
	 * Wire up the Pro features (after the free plugin, on plugins_loaded).
	 */
	public static function init() {
		if ( is_admin() ) {
			Pro_Admin::init();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			Pro_Admin::register_cli();
		}
		add_filter( 'ironveil_audit_checks', array( __CLASS__, 'audit_checks' ) );
		if ( ! License::is_pro() ) {
			return;
		}
		// Email alerts.
		Notifier::register( 'scan', 'ironveil_scan_complete', array( __CLASS__, 'alert_scan' ), 2 );
		Notifier::register( 'server', 'ironveil_server_scan_complete', array( __CLASS__, 'alert_server_scan' ), 2 );
		Notifier::register( 'lockout', 'ironveil_lockout', array( __CLASS__, 'alert_lockout' ), 2 );
		Notifier::register( 'lockout', 'ironveil_ip_autoblocked', array( __CLASS__, 'alert_autoblocked' ), 2 );
		Notifier::register( 'admin_login', 'ironveil_login_complete', array( __CLASS__, 'alert_admin_login' ), 1 );
		Notifier::register( 'plugin', 'ironveil_component_change', array( __CLASS__, 'alert_component' ), 2 );

		// Scanner: ClamAV, extra folders, deep scans, WPScan, auto-remediation.
		add_filter( 'ironveil_scan_deep', array( __CLASS__, 'scan_deep' ) );
		add_filter( 'ironveil_scan_roots', array( __CLASS__, 'scan_roots' ) );
		add_filter( 'ironveil_safe_roots', array( __CLASS__, 'safe_roots' ) );
		add_filter( 'ironveil_scan_engine_available', array( '\IronVeil\ClamAV', 'available' ) );
		add_filter( 'ironveil_scan_all_file_types', array( __CLASS__, 'scan_all_file_types' ) );
		add_filter( 'ironveil_scan_engine_file', array( __CLASS__, 'engine_file' ), 10, 2 );
		add_filter( 'ironveil_engine_check_content', array( __CLASS__, 'engine_content' ), 10, 2 );
		add_filter( 'ironveil_component_vulnerabilities', array( __CLASS__, 'vulnerabilities' ), 10, 4 );
		add_action( 'ironveil_new_finding', array( __CLASS__, 'auto_remediate' ), 10, 5 );

		// Signatures: signed update feed + custom rules.
		add_filter( 'ironveil_signature_sets', array( __CLASS__, 'signature_sets' ) );
		add_filter( 'ironveil_signature_fingerprint', array( __CLASS__, 'signature_fingerprint' ) );
		add_action( 'ironveil_daily_maintenance', array( __CLASS__, 'daily' ) );
	}

	// ------------------------------------------------------------------ License.

	/**
	 * Is the site entitled to Pro (valid license or trial)?
	 *
	 * With Freemius loaded, Freemius decides and the answer is remembered in an
	 * autoloaded option (written only when it changes). The early firewall
	 * loader runs before Freemius exists and uses that remembered answer.
	 *
	 * @return bool
	 */
	public static function entitled() {
		if ( function_exists( 'ironveil_fs' ) ) {
			if ( ironveil_fs() instanceof Freemius_Fallback ) {
				return false;
			}
			$ok = (bool) ironveil_fs()->can_use_premium_code();
			self::remember( $ok );
			return $ok;
		}
		return hash_equals( self::state_mac(), (string) get_option( self::STATE_OPTION, '' ) );
	}

	/**
	 * @param bool $ok Entitled.
	 */
	private static function remember( $ok ) {
		$want = $ok ? self::state_mac() : '';
		if ( (string) get_option( self::STATE_OPTION, '' ) !== $want ) {
			update_option( self::STATE_OPTION, $want, true );
		}
	}

	/**
	 * @return string MAC bound to this site and its secret keys.
	 */
	private static function state_mac() {
		$secret = ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'NONCE_SALT' ) ? NONCE_SALT : '' );
		return hash_hmac( 'sha256', 'ironveil-pro|' . (string) get_option( 'siteurl' ), 'ironveil|' . $secret );
	}

	// ------------------------------------------------------------------ Settings.

	/**
	 * Pro settings, their defaults and the value each takes while Pro is inactive.
	 */
	private static function register_settings() {
		Settings::extend(
			array( __CLASS__, 'schema' ),
			array(
				'fw_blocked_countries'  => '',
				'scan_auto_quarantine'  => 0,
				'scan_auto_repair_core' => 0,
				'scan_deep_days'        => 7,
				'scan_extra_paths'      => '',
				'clamav_mode'           => 'auto',
				'clamav_socket'         => '',
				'clamav_all_files'      => 1,
				'clamav_max_mb'         => 20,
				'sig_feed_url'          => '',
				'sig_feed_key'          => '',
				'custom_signatures'     => '',
				'wpscan_token'          => '',
				'notify_events'         => array( 'scan', 'new_admin', 'server' ),
			)
		);
		License::register_locks(
			array(
				'fw_blocked_countries'  => '',
				'scan_auto_quarantine'  => 0,
				'scan_auto_repair_core' => 0,
				'scan_deep_days'        => 0,
				'scan_extra_paths'      => '',
				'clamav_mode'           => 'off',
				'clamav_socket'         => '',
				'clamav_all_files'      => 0,
				'clamav_max_mb'         => 20,
				'sig_feed_url'          => '',
				'sig_feed_key'          => '',
				'custom_signatures'     => '',
				'wpscan_token'          => '',
				'notify_events'         => array( 'new_admin' ), // Security-critical alerts stay on without Pro.
			)
		);
	}

	/**
	 * Add the Pro fields to the settings schema.
	 *
	 * @param array $schema Schema.
	 * @return array
	 */
	public static function schema( array $schema ) {
		if ( isset( $schema['notify_events'] ) ) {
			$schema['notify_events']['options'] = array(
				'scan'        => __( 'A scan finds new problems', 'ironveil-security' ),
				'server'      => __( 'A server scan finds new problems', 'ironveil-security' ),
				'lockout'     => __( 'An IP is locked out / auto-blocked', 'ironveil-security' ),
				'admin_login' => __( 'An administrator logs in', 'ironveil-security' ),
				'plugin'      => __( 'Plugins or themes are installed / activated', 'ironveil-security' ),
			) + (array) $schema['notify_events']['options'];
			$schema['notify_events']['default'] = array( 'scan', 'new_admin', 'server' );
		}
		$fields = array(
			'fw_blocked_countries'  => array(
				'page'     => 'firewall',
				'type'     => 'text',
				'label'    => __( 'Blocked countries', 'ironveil-security' ),
				'desc'     => __( 'Comma separated two-letter ISO codes, e.g. "KP, IR". Uses the CF-IPCountry (Cloudflare) or GEOIP_COUNTRY_CODE server variable – zero lookup cost.', 'ironveil-security' ),
				'default'  => '',
				'sanitize' => array( __CLASS__, 'sanitize_countries' ),
			),
			'scan_auto_quarantine'  => array(
				'page'    => 'scanner',
				'type'    => 'bool',
				'label'   => __( 'Auto-quarantine critical findings', 'ironveil-security' ),
				'desc'    => __( 'Automatically moves web shells and PHP files hidden in uploads into the quarantine (reversible). Never touches WordPress core files.', 'ironveil-security' ),
				'default' => 0,
			),
			'scan_auto_repair_core' => array(
				'page'    => 'scanner',
				'type'    => 'bool',
				'label'   => __( 'Auto-repair modified WordPress core files', 'ironveil-security' ),
				'desc'    => __( 'Replaces them with the official copy, verified against the wordpress.org checksum before writing.', 'ironveil-security' ),
				'default' => 0,
			),
			'scan_deep_days'        => array(
				'page'    => 'scanner',
				'type'    => 'int',
				'label'   => __( 'Deep scan every (days)', 'ironveil-security' ),
				'desc'    => __( 'Normal scans skip files unchanged since they were last found clean. A deep scan re-checks every file (useful after virus-database updates). 0 = never automatically.', 'ironveil-security' ),
				'min'     => 0,
				'max'     => 90,
				'default' => 7,
			),
			'scan_extra_paths'      => array(
				'page'     => 'scanner',
				'type'     => 'textarea',
				'label'    => __( 'Additional server folders to scan', 'ironveil-security' ),
				'desc'     => __( 'Absolute paths outside WordPress, one per line (e.g. other sites on this account). Only folders PHP may read are scanned; system folders are refused.', 'ironveil-security' ),
				'default'  => '',
				'sanitize' => array( __CLASS__, 'sanitize_paths' ),
			),
			'clamav_mode'           => array(
				'page'    => 'scanner',
				'type'    => 'select',
				'label'   => __( 'ClamAV antivirus engine', 'ironveil-security' ),
				'desc'    => __( 'Uses the clamd daemon on this server (install clamav-daemon and keep freshclam running). Files are streamed to it, so no shell access is needed.', 'ironveil-security' ),
				'options' => array(
					'auto'   => __( 'Auto-detect clamd (recommended)', 'ironveil-security' ),
					'custom' => __( 'Use the socket below', 'ironveil-security' ),
					'off'    => __( 'Off', 'ironveil-security' ),
				),
				'default' => 'auto',
			),
			'clamav_socket'         => array(
				'page'    => 'scanner',
				'type'    => 'text',
				'label'   => __( 'clamd socket', 'ironveil-security' ),
				'desc'    => __( 'e.g. /run/clamav/clamd.ctl or 127.0.0.1:3310 (TCP is limited to local/private addresses).', 'ironveil-security' ),
				'default' => '',
			),
			'clamav_all_files'      => array(
				'page'    => 'scanner',
				'type'    => 'bool',
				'label'   => __( 'With ClamAV: scan every file type', 'ironveil-security' ),
				'desc'    => __( 'Also scans images, archives, documents and binaries (not just code files). Only new or changed files are sent after the first scan.', 'ironveil-security' ),
				'default' => 1,
			),
			'clamav_max_mb'         => array(
				'page'    => 'scanner',
				'type'    => 'int',
				'label'   => __( 'ClamAV maximum file size (MB)', 'ironveil-security' ),
				'desc'    => __( 'Keep this at or below clamd\'s StreamMaxLength (default 25).', 'ironveil-security' ),
				'min'     => 1,
				'max'     => 500,
				'default' => 20,
			),
			'sig_feed_url'          => array(
				'page'     => 'scanner',
				'type'     => 'text',
				'label'    => __( 'Signature update feed URL', 'ironveil-security' ),
				'desc'     => __( 'Leave empty to use the official IronVeil feed. Or enter the https:// URL of your own signed signatures.json. Checked daily. Can be locked with IRONVEIL_SIG_FEED_URL in wp-config.php.', 'ironveil-security' ),
				'default'  => '',
				'sanitize' => array( __CLASS__, 'sanitize_feed_url' ),
			),
			'sig_feed_key'          => array(
				'page'     => 'scanner',
				'type'     => 'text',
				'label'    => __( 'Feed public key (Ed25519, base64)', 'ironveil-security' ),
				'desc'     => __( 'Leave empty for the official IronVeil feed. Updates are only accepted if signed by the matching private key. Can be locked with IRONVEIL_SIG_FEED_KEY in wp-config.php.', 'ironveil-security' ),
				'default'  => '',
				'sanitize' => array( __CLASS__, 'sanitize_feed_key' ),
			),
			'custom_signatures'     => array(
				'page'     => 'scanner',
				'type'     => 'textarea',
				'label'    => __( 'Custom signatures', 'ironveil-security' ),
				'desc'     => __( 'One per line: set|severity|description|regex — set is php, js or config; severity 1 (low) to 4 (critical). Example: php|4|Acme backdoor|acme_backdoor\s*\(', 'ironveil-security' ),
				'default'  => '',
				'sanitize' => array( __CLASS__, 'sanitize_signatures' ),
			),
			'wpscan_token'          => array(
				'page'    => 'scanner',
				'type'    => 'password',
				'label'   => __( 'WPScan API token (optional)', 'ironveil-security' ),
				'desc'    => __( 'Enables CVE-level vulnerability matching for plugins, themes and core. Without it, IronVeil still detects outdated, closed and abandoned components.', 'ironveil-security' ),
				'default' => '',
			),
		);
		return array_merge( $schema, $fields );
	}

	/**
	 * @param mixed $value Raw.
	 * @return string "KP, IR" style list of valid codes.
	 */
	public static function sanitize_countries( $value ) {
		$value = is_scalar( $value ) ? strtoupper( (string) $value ) : '';
		preg_match_all( '/\b[A-Z]{2}\b/', $value, $m );
		return implode( ', ', array_slice( array_values( array_unique( $m[0] ) ), 0, 250 ) );
	}

	/**
	 * @param mixed $value Raw.
	 * @return string Valid folders, one per line.
	 */
	public static function sanitize_paths( $value ) {
		$value = is_scalar( $value ) ? (string) $value : '';
		$keep  = array();
		foreach ( array_slice( preg_split( '/[\r\n]+/', $value ), 0, 50 ) as $line ) {
			$path = self::validate_extra_path( trim( $line ) );
			if ( $path ) {
				$keep[] = $path;
			}
		}
		return implode( "\n", array_unique( $keep ) );
	}

	/**
	 * Regexes must be stored verbatim (sanitize_text_field would corrupt them);
	 * only valid, safely-compiling lines are kept. Output is always escaped.
	 *
	 * @param mixed $value Raw.
	 * @return string
	 */
	public static function sanitize_signatures( $value ) {
		$value = is_scalar( $value ) ? (string) $value : '';
		$keep  = array();
		foreach ( array_slice( preg_split( '/\r\n|\r|\n/', $value ), 0, 500 ) as $line ) {
			$line = trim( (string) preg_replace( '/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', '', $line ) );
			if ( '' === $line ) {
				continue;
			}
			if ( '#' === $line[0] || ! Signature_Feed::parse_custom( $line )['errors'] ) {
				$keep[] = $line;
			}
		}
		return implode( "\n", $keep );
	}

	/**
	 * @param mixed $value Raw.
	 * @return string
	 */
	public static function sanitize_feed_url( $value ) {
		return (string) esc_url_raw( is_scalar( $value ) ? trim( (string) $value ) : '', array( 'https' ) );
	}

	/**
	 * @param mixed $value Raw.
	 * @return string
	 */
	public static function sanitize_feed_key( $value ) {
		return (string) preg_replace( '/[^A-Za-z0-9+\/=]/', '', is_scalar( $value ) ? (string) $value : '' );
	}

	// ------------------------------------------------------------------ Firewall.

	/**
	 * Country blocking via an edge/server-provided header (no lookups).
	 *
	 * @param string $ip Client IP (unused: the country comes from the edge).
	 * @return string|null Deny reason.
	 */
	public static function country_check( $ip ) {
		unset( $ip );
		$countries = Settings::lines( 'fw_blocked_countries' );
		if ( ! $countries ) {
			return null;
		}
		foreach ( array( 'HTTP_CF_IPCOUNTRY', 'GEOIP_COUNTRY_CODE', 'HTTP_X_COUNTRY_CODE' ) as $h ) {
			if ( ! empty( $_SERVER[ $h ] ) ) {
				$cc = strtoupper( substr( sanitize_key( wp_unslash( $_SERVER[ $h ] ) ), 0, 2 ) );
				return in_array( $cc, array_map( 'strtoupper', $countries ), true ) ? 'country:' . $cc : null;
			}
		}
		return null;
	}

	// ------------------------------------------------------------------ Scanner.

	/**
	 * Scheduled deep scans.
	 *
	 * @param bool $deep Requested.
	 * @return bool
	 */
	public static function scan_deep( $deep ) {
		$days = (int) Settings::get( 'scan_deep_days' );
		if ( ! $deep && $days > 0 && get_option( 'ironveil_last_scan_end' ) && (int) get_option( 'ironveil_last_deep_scan' ) < time() - DAY_IN_SECONDS * $days ) {
			return true;
		}
		return (bool) $deep;
	}

	/**
	 * @return string[] Validated extra folders.
	 */
	private static function extra_paths() {
		$out = array();
		foreach ( Settings::lines( 'scan_extra_paths' ) as $p ) {
			$p = self::validate_extra_path( $p );
			if ( $p ) {
				$out[] = $p;
			}
		}
		return $out;
	}

	/**
	 * @param array $roots Roots.
	 * @return array
	 */
	public static function scan_roots( $roots ) {
		return array_merge( (array) $roots, self::extra_paths() );
	}

	/**
	 * @param array $roots Folders where files may be repaired or quarantined.
	 * @return array
	 */
	public static function safe_roots( $roots ) {
		return array_merge( (array) $roots, self::extra_paths() );
	}

	/**
	 * Validate an additional scan root: absolute, readable, a directory, not
	 * inside WordPress (already scanned) and not a system location.
	 *
	 * @param string $path Path.
	 * @return string|false Canonical path.
	 */
	public static function validate_extra_path( $path ) {
		$path = trim( (string) $path );
		if ( '' === $path || ( '/' !== $path[0] && ! preg_match( '~^[A-Za-z]:[\\\\/]~', $path ) ) ) {
			return false;
		}
		$real = @realpath( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- open_basedir.
		if ( ! $real || ! @is_dir( $real ) || ! @is_readable( $real ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return false;
		}
		$real = rtrim( wp_normalize_path( $real ), '/' );
		if ( '' === $real ) {
			return false; // Filesystem root.
		}
		foreach ( array( '/proc', '/sys', '/dev', '/etc', '/boot', '/bin', '/sbin', '/lib', '/lib64', '/usr', '/run', '/var/run', '/var/lib', '/var/cache', '/root', '/snap' ) as $deny ) {
			if ( $real === $deny || 0 === strpos( $real . '/', $deny . '/' ) ) {
				return false;
			}
		}
		$wp = rtrim( wp_normalize_path( (string) realpath( ABSPATH ) ), '/' );
		if ( 0 === strpos( $real . '/', $wp . '/' ) || 0 === strpos( $wp . '/', $real . '/' ) ) {
			return false; // Inside WordPress (already scanned) or a parent of it (would rescan it).
		}
		return $real;
	}

	/**
	 * @return bool
	 */
	public static function scan_all_file_types() {
		return (bool) Settings::get( 'clamav_all_files' );
	}

	/**
	 * @param array  $result Default (skipped).
	 * @param string $abs    File.
	 * @return array
	 */
	public static function engine_file( $result, $abs ) {
		return ClamAV::scan_file( $abs );
	}

	/**
	 * @param array  $result  Default (skipped).
	 * @param string $content Content.
	 * @return array
	 */
	public static function engine_content( $result, $content ) {
		return ClamAV::available() ? ClamAV::scan_string( (string) $content ) : $result;
	}

	/**
	 * WPScan vulnerability lookup (only with an API token; cached 24h).
	 *
	 * @param array  $vulns Found so far.
	 * @param string $type  core|plugin|theme.
	 * @param string $slug  Slug.
	 * @param string $ver   Installed version.
	 * @return array[]
	 */
	public static function vulnerabilities( $vulns, $type, $slug, $ver ) {
		$vulns = (array) $vulns;
		$token = trim( (string) Settings::get( 'wpscan_token' ) );
		if ( '' === $token ) {
			return $vulns;
		}
		$path = 'core' === $type ? 'wordpresses/' . str_replace( '.', '', $ver ) : ( 'theme' === $type ? 'themes/' : 'plugins/' ) . rawurlencode( $slug );
		$key  = 'ironveil_wps_' . md5( $path );
		$data = get_transient( $key );
		if ( false === $data ) {
			$res  = wp_remote_get(
				'https://wpscan.com/api/v3/' . $path,
				array(
					'timeout' => 6,
					'headers' => array( 'Authorization' => 'Token token=' . $token ),
				)
			);
			$data = array();
			if ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) {
				$json = json_decode( wp_remote_retrieve_body( $res ), true );
				$data = is_array( $json ) ? (array) reset( $json ) : array();
			}
			set_transient( $key, $data, DAY_IN_SECONDS );
		}
		foreach ( isset( $data['vulnerabilities'] ) ? (array) $data['vulnerabilities'] : array() as $v ) {
			$fixed = isset( $v['fixed_in'] ) ? (string) $v['fixed_in'] : '';
			if ( 'core' !== $type && '' !== $fixed && version_compare( $ver, $fixed, '>=' ) ) {
				continue;
			}
			$cves    = isset( $v['references']['cve'] ) ? array_map(
				static function ( $c ) {
					return 'CVE-' . $c;
				},
				(array) $v['references']['cve']
			) : array();
			$vulns[] = array(
				'id'       => isset( $v['id'] ) ? (string) $v['id'] : md5( (string) wp_json_encode( $v ) ),
				'title'    => substr( sanitize_text_field( isset( $v['title'] ) ? $v['title'] : 'Known vulnerability' ), 0, 150 ),
				'fixed_in' => $fixed,
				'refs'     => $cves,
				'sev'      => '' === $fixed ? Signatures::SEV_CRITICAL : Signatures::SEV_HIGH,
			);
		}
		return $vulns;
	}

	/**
	 * Optional automatic remediation of the most dangerous findings.
	 *
	 * @param int    $id   Issue id.
	 * @param string $type Type.
	 * @param int    $sev  Severity.
	 * @param string $path Path.
	 * @param array  $data Data.
	 */
	public static function auto_remediate( $id, $type, $sev, $path, $data ) {
		$data = (array) $data;
		if ( 'core_modified' === $type && Settings::get( 'scan_auto_repair_core' ) ) {
			Scanner::fix_issue( $id, 'repair', true );
			return;
		}
		if ( ! Settings::get( 'scan_auto_quarantine' ) ) {
			return;
		}
		$auto = ( 'php_in_uploads' === $type || 'php_in_non_php' === $type || ( 'clamav' === $type && isset( $data['fixable'] ) && 'quarantine' === $data['fixable'] && 0 !== strpos( (string) ( $data['sig'] ?? '' ), 'PUA.' ) ) )
			|| ( 'malware' === $type && Signatures::SEV_CRITICAL === (int) $sev && isset( $data['fixable'] ) && 'quarantine' === $data['fixable'] );
		if ( $auto ) {
			Scanner::fix_issue( $id, 'quarantine', true );
		}
	}

	// ------------------------------------------------------------------ Signatures.

	/**
	 * Add the signed feed's rules and the admin's custom rules.
	 *
	 * @param array $sets Sets.
	 * @return array
	 */
	public static function signature_sets( $sets ) {
		$sets   = (array) $sets;
		$feed   = Signature_Feed::state();
		$custom = Signature_Feed::parse_custom( (string) Settings::get( 'custom_signatures' ) );
		foreach ( Signatures::SETS as $set ) {
			if ( ! empty( $feed['rules'][ $set ] ) && is_array( $feed['rules'][ $set ] ) ) {
				$sets[ $set ] += $feed['rules'][ $set ];
			}
			$sets[ $set ] += $custom['rules'][ $set ];
		}
		if ( ! empty( $feed['names'] ) ) {
			$sets['filenames'] = array_values( array_unique( array_merge( (array) $sets['filenames'], (array) $feed['names'] ) ) );
		}
		return $sets;
	}

	/**
	 * @param string $fp Fingerprint.
	 * @return string
	 */
	public static function signature_fingerprint( $fp ) {
		$feed = Signature_Feed::state();
		return $fp . '|' . (int) $feed['version'] . '|' . md5( (string) Settings::get( 'custom_signatures' ) ) . '|' . ( ClamAV::available() ? 'clam' : '' );
	}

	/**
	 * Daily: signature feed.
	 */
	public static function daily() {
		if ( '' !== Signature_Feed::url() ) {
			Signature_Feed::update();
		}
	}

	/**
	 * Security checklist: extended protection.
	 *
	 * @param array $checks Checks.
	 * @return array
	 */
	public static function audit_checks( $checks ) {
		$checks['early'] = array( __( 'Extended protection (firewall loads before other plugins)', 'ironveil-security' ), Installer::mu_loader_active() ? 'good' : 'warn', '', 3 );
		return $checks;
	}

	// ------------------------------------------------------------------ Alerts.

	/**
	 * @param int   $scan_id Scan id.
	 * @param array $summary new, items.
	 */
	public static function alert_scan( $scan_id, $summary ) {
		if ( empty( $summary['new'] ) ) {
			return;
		}
		$lines = array();
		foreach ( (array) $summary['items'] as $item ) {
			$lines[] = '- [' . $item['sev'] . '] ' . $item['detail'] . ( $item['path'] ? ' — ' . $item['path'] : '' );
		}
		Notifier::send(
			'scan',
			/* translators: %d: number of findings */
			sprintf( _n( '%d new security finding', '%d new security findings', (int) $summary['new'], 'ironveil-security' ), (int) $summary['new'] ),
			__( 'The scan found new issues:', 'ironveil-security' ) . "\n\n" . implode( "\n", array_slice( $lines, 0, 30 ) ),
			0
		);
	}

	/**
	 * @param int   $id      Server scan id.
	 * @param array $summary new, items.
	 */
	public static function alert_server_scan( $id, $summary ) {
		if ( empty( $summary['new'] ) ) {
			return;
		}
		$lines = array();
		foreach ( (array) $summary['items'] as $item ) {
			$lines[] = '- [' . $item['sev'] . '] ' . $item['detail'];
		}
		Notifier::send(
			'server_scan',
			/* translators: %d: number of problems */
			sprintf( _n( 'Server scan: %d new problem', 'Server scan: %d new problems', (int) $summary['new'], 'ironveil-security' ), (int) $summary['new'] ),
			__( 'The server scan found new problems:', 'ironveil-security' ) . "\n\n" . implode( "\n", array_slice( $lines, 0, 30 ) ) . "\n\n" . __( 'Review them in IronVeil → Server Scan.', 'ironveil-security' ),
			0
		);
	}

	/**
	 * @param string $ip       IP.
	 * @param int    $duration Seconds.
	 */
	public static function alert_lockout( $ip, $duration ) {
		/* translators: 1: IP address 2: minutes */
		Notifier::send( 'lockout', __( 'Login lockout', 'ironveil-security' ), sprintf( __( "IP %1\$s was locked out of the login page for %2\$d minutes after repeated failed logins.\n(Further lockouts in the next 15 minutes are not emailed.)", 'ironveil-security' ), $ip, (int) ( $duration / 60 ) ) );
	}

	/**
	 * @param string $ip  IP.
	 * @param string $why Reason.
	 */
	public static function alert_autoblocked( $ip, $why ) {
		/* translators: 1: IP address 2: reason */
		Notifier::send( 'autoblock', __( 'IP auto-blocked', 'ironveil-security' ), sprintf( __( "IP %1\$s was blocked by the firewall (%2\$s).\n(Further blocks in the next 15 minutes are not emailed.)", 'ironveil-security' ), $ip, $why ) );
	}

	/**
	 * @param \WP_User $user User.
	 */
	public static function alert_admin_login( $user ) {
		if ( $user instanceof \WP_User && user_can( $user, 'manage_options' ) ) {
			/* translators: 1: user name 2: IP address 3: date and time (UTC) */
			Notifier::send( 'admin_login_' . $user->ID, __( 'Administrator login', 'ironveil-security' ), sprintf( __( "Administrator \"%1\$s\" logged in from %2\$s at %3\$s (UTC).\nIf this wasn't you, change the password and review Users.", 'ironveil-security' ), $user->user_login, IP::client(), gmdate( 'Y-m-d H:i:s' ) ), 300 );
		}
	}

	/**
	 * @param string $what What changed.
	 * @param string $name Name.
	 */
	public static function alert_component( $what, $name ) {
		/* translators: 1: kind of change 2: plugin or theme name */
		Notifier::send( 'component', __( 'Plugin/theme change', 'ironveil-security' ), sprintf( __( 'Change detected: %1$s – %2$s', 'ironveil-security' ), $what, $name ), 300 );
	}
}
