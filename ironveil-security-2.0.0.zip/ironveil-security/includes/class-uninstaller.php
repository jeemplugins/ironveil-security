<?php
/**
 * Uninstall: remove every table, option, user meta, cron event, rule block
 * and file IronVeil created. Define IRONVEIL_KEEP_DATA to keep data.
 *
 * Called by Freemius ("after_uninstall"), or by WordPress directly while
 * Freemius is not configured. There is deliberately no uninstall.php: it
 * would stop Freemius from running its own uninstall step.
 *
 * @package IronVeil
 */

namespace IronVeil;

defined( 'ABSPATH' ) || exit;

final class Uninstaller {

	/**
	 * Without Freemius, register the uninstall callback with WordPress itself
	 * (Freemius registers its own when it is configured).
	 */
	public static function register_fallback_hook() {
		if ( ironveil_fs() instanceof Freemius_Fallback ) {
			register_uninstall_hook( IRONVEIL_FILE, 'ironveil_fs_uninstall_cleanup' );
		}
	}

	/**
	 * Remove all data (every site of a network).
	 */
	public static function run() {
		if ( defined( 'IRONVEIL_KEEP_DATA' ) && IRONVEIL_KEEP_DATA ) {
			return;
		}
		global $wpdb;
		if ( is_multisite() ) {
			foreach ( get_sites(
				array(
					'fields' => 'ids',
					'number' => 0,
				)
			) as $blog_id ) {
				switch_to_blog( $blog_id );
				self::site();
				restore_current_blog();
			}
		} else {
			self::site();
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s", $wpdb->esc_like( 'ironveil' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( is_multisite() ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s", $wpdb->esc_like( 'ironveil' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		}
		$mu = trailingslashit( WPMU_PLUGIN_DIR ) . '0-ironveil-firewall.php';
		if ( is_file( $mu ) && false !== strpos( (string) file_get_contents( $mu, false, null, 0, 400 ), 'IronVeil' ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			wp_delete_file( $mu );
		}
		self::quarantine_folders();
	}

	/**
	 * Remove data for the current site.
	 */
	private static function site() {
		global $wpdb;
		foreach ( array( 'ironveil_log', 'ironveil_blocks', 'ironveil_files', 'ironveil_issues' ) as $t ) {
			$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . $t ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.DirectDatabaseQuery.SchemaChange
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( 'ironveil' ) . '%', $wpdb->esc_like( '_transient_ironveil' ) . '%', $wpdb->esc_like( '_transient_timeout_ironveil' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		foreach ( array( 'ironveil_hourly', 'ironveil_daily', 'ironveil_scheduled_scan', 'ironveil_scan_step', 'ironveil_server_scan' ) as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		$up = wp_upload_dir( null, false );
		if ( ! empty( $up['basedir'] ) && is_file( $up['basedir'] . '/.htaccess' ) ) {
			insert_with_markers( $up['basedir'] . '/.htaccess', 'IronVeil Security', array() );
		}
		if ( is_file( ABSPATH . '.htaccess' ) && false !== strpos( (string) file_get_contents( ABSPATH . '.htaccess' ), 'BEGIN IronVeil Server Protection' ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			insert_with_markers( ABSPATH . '.htaccess', 'IronVeil Server Protection', array() );
		}
	}

	/**
	 * Quarantine folders: uploads/ironveil-quarantine-<random> (1.3.2+) and the
	 * legacy wp-content/ironveil-quarantine.
	 */
	private static function quarantine_folders() {
		$up      = wp_upload_dir( null, false );
		$folders = array( trailingslashit( WP_CONTENT_DIR ) . 'ironveil-quarantine' );
		if ( ! empty( $up['basedir'] ) && is_dir( $up['basedir'] ) ) {
			foreach ( (array) scandir( $up['basedir'] ) as $d ) {
				if ( preg_match( '/^ironveil-quarantine-[a-f0-9]{16}$/', (string) $d ) ) {
					$folders[] = trailingslashit( $up['basedir'] ) . $d;
				}
			}
		}
		foreach ( $folders as $q ) {
			if ( ! is_dir( $q ) ) {
				continue;
			}
			foreach ( (array) scandir( $q ) as $f ) {
				if ( is_file( $q . '/' . $f ) ) {
					wp_delete_file( $q . '/' . $f );
				}
			}
			@rmdir( $q ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
		}
	}
}
