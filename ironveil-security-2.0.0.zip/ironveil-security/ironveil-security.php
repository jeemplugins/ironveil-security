<?php
/**
 * Plugin Name:       IronVeil Security
 * Plugin URI:        https://jeemplugins.com/ironveilsecurity
 * Description:       Lightweight, high-grade WordPress security: zero-query web application firewall with threat-intelligence feeds, brute-force and bot protection, incremental malware and file-integrity scanner with quarantine and core repair, server security scanner, hardening and a tamper-evident activity log.
 * Version:           2.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Jassim T Mohammad
 * Author URI:        https://jeemplugins.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ironveil-security
 * Domain Path:       /languages
 *
 * @fs_premium_only /includes/pro/
 *
 * @package IronVeil
 */

defined( 'ABSPATH' ) || exit;

if ( function_exists( 'ironveil_fs' ) ) {
	// Another IronVeil build (Free or Pro) is already loaded: Freemius switches to this one.
	ironveil_fs()->set_basename( true, __FILE__ );
	return;
}

if ( defined( 'IRONVEIL_VERSION' ) ) {
	return; // Guard against a duplicate copy of the plugin.
}

define( 'IRONVEIL_VERSION', '2.0.0' );
define( 'IRONVEIL_DB_VERSION', 1 );
define( 'IRONVEIL_FILE', __FILE__ );
define( 'IRONVEIL_DIR', __DIR__ . '/' );
define( 'IRONVEIL_URL', plugin_dir_url( __FILE__ ) );
define( 'IRONVEIL_BASENAME', plugin_basename( __FILE__ ) );

require_once IRONVEIL_DIR . 'includes/autoload.php';

if ( ! function_exists( 'ironveil_fs' ) ) {
	/**
	 * Freemius SDK (licensing, subscriptions, updates of the Pro version).
	 *
	 * Copy the product ID and public key from the Freemius Developer Dashboard
	 * (Product → SDK Integration). Until both are filled in, IronVeil runs
	 * without Freemius: Free features only, no opt-in screen and no account pages.
	 *
	 * @return Freemius|\IronVeil\Freemius_Fallback
	 */
	function ironveil_fs() {
		global $ironveil_fs;
		if ( ! isset( $ironveil_fs ) ) {
			$ironveil_fs_id  = '41959'; // Freemius product ID (Developer Dashboard → Product → SDK Integration).
			$ironveil_fs_key = 'pk_b04da54c3a8566ef5768edb7b389b'; // Freemius public key (safe to ship; the secret key never goes in the plugin).
			if ( '' !== $ironveil_fs_id && '' !== $ironveil_fs_key && is_readable( IRONVEIL_DIR . 'freemius/start.php' ) ) {
				if ( function_exists( 'wp_prime_option_caches' ) ) {
					// The SDK reads these (often missing) options on every request: one query instead of three.
					wp_prime_option_caches( array( 'fs_storage_logger', 'fs_clone_management', 'fs_cache_' . $ironveil_fs_id ) );
				}
				require_once IRONVEIL_DIR . 'freemius/start.php';
				$ironveil_fs = fs_dynamic_init(
					array(
						'id'                  => $ironveil_fs_id,
						'slug'                => 'ironveil-security',
						'premium_slug'        => 'ironveil-security-pro',
						'type'                => 'plugin',
						'public_key'          => $ironveil_fs_key,
						'is_premium'          => true,
						'premium_suffix'      => 'Pro',
						'has_premium_version' => true,
						'has_addons'          => false,
						'has_paid_plans'      => true,
						'is_org_compliant'    => true,
						'menu'                => array(
							'slug'       => 'ironveil',
							'first-path' => 'admin.php?page=ironveil',
							'contact'    => false,
							'support'    => false,
						),
					)
				);
			} else {
				$ironveil_fs = new \IronVeil\Freemius_Fallback();
			}
		}
		return $ironveil_fs;
	}
}

ironveil_fs();
do_action( 'ironveil_fs_loaded' );

if ( ! function_exists( 'ironveil_fs_uninstall_cleanup' ) ) {
	/**
	 * Remove all IronVeil data when the plugin is deleted (called by Freemius,
	 * or directly by WordPress when Freemius is not configured).
	 */
	function ironveil_fs_uninstall_cleanup() {
		\IronVeil\Uninstaller::run();
	}
}
ironveil_fs()->add_action( 'after_uninstall', 'ironveil_fs_uninstall_cleanup' );

// Pro modules. Freemius removes this block and includes/pro/ from the free build.
if ( ironveil_fs()->is__premium_only() ) {
	if ( class_exists( '\IronVeil\Pro' ) ) {
		\IronVeil\Pro::boot();
	}
}

// 1) The firewall runs immediately, before most other plugins are loaded
// (or even earlier, from mu-plugins, when "Extended protection" is on;
// boot() is idempotent so the second call is a no-op).
\IronVeil\Firewall::boot();

// 2) Everything else is wired up on plugins_loaded.
add_action( 'plugins_loaded', array( '\IronVeil\Plugin', 'instance' ), 1 );

register_activation_hook( __FILE__, array( '\IronVeil\Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( '\IronVeil\Installer', 'deactivate' ) );
